import { useState } from "react";
import Products from "../DATA.json"

export default function Welcome(props) {
    const [data, setData] = useState(Products);
    const [plist,setPList] = useState(data)
    const [name, setName] = useState("")

    const filter = (name) => {
        let fData = data.filter(p => p.name.indexOf(name) >= 0);
        setPList(fData);
    }
    return (
        <>
            <span>Tim kiem: </span>
            <input type="text" value={name} onChange={
                e => {
                    let v = e.target.value;
                    setName(v);
                    filter(v);
                }
            }/>
            <span>Tong so film: {plist.length}</span>
            <div className="plist" style={{ display: "flex", justifyContent: "flex-start", flexWrap: "wrap" }}>
                {plist.map(p => (
                    <div className="product" style={{ backgroundColor: "Highlight" }}>
                        <span>name: {p.name}</span>
                        <img src={p.url} width={200} height={150} />
                        <span>price: {p.price} $</span>
                    </div>
                ))}
            </div>
        </>
    )
}