import { useState } from "react"

export default function Header(props){
    const [user,setUser] = useState(props.user)
    console.log(user);
    return (
        <div className="header">
            {user && (
                <div>
                    <span>name: {user.name}</span>
                    <span>role: {user.role}</span>

                </div>
            )}
        </div>
    )
}