import logo from './logo.svg';
import './App.css';
import Login from './components/Login';
import Header from './components/layout/Header';
import { useState } from 'react';
import Welcome from './components/Welcome';

function App() {

  const [user, setUser] = useState(null)

  const loginSuccess = (user) => {
    setUser(user);
  }
  return (
    <div className="App">
      <Login/>
      {/* {
        user == null ? <Login loginSuccess={loginSuccess} /> :
          <>
            <Header user={user}/>
            <Welcome /></>
      } */}
    </div>
  );
}

export default App;
